<?php
if(isset($_POST['Login']))
    {$uname = $_POST['uname'];
	$psw = $_POST['psw'];
    }

// Server name must be localhost
$servername = "localhost";

// In my case, user name will be root
$username = "root";

// Password is empty
$password = "";

// Creating a connection
$conn = new mysqli($servername,
			$username, $password);

// Check connection
if ($conn->connect_error) {
	die("Connection failure: "
		. $conn->connect_error);
}

// Creating a database named geekdata
//$sql = "INSERT INTO `feedback` (`Name`, `Age`, `Marks`, `Mobile`) VALUES ('$name', '$age', '$marks', '$mobile');";  
//if ($conn->query($sql) == TRUE) {
$sql = "SELECT `psw` FROM techfest.`login` WHERE uname='$uname';";
$passwd="Hello";
if($conn->query($sql) == TRUE)
{
	$result=$conn->query($sql);
	if($result->num_rows>0)
	{
		while($row = $result->fetch_assoc())
		{
			$passwd==$row["psw"];
		}
	}
	else
	{
		echo "0 results";
	}
	if("$passwd"=="$psw") 
	{
	echo "password is authenticated";
	}
	
}
else 
{
	 $conn->error;

}

// Closing connection
$conn->close();
?>
