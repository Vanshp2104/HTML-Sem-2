<?php
if(isset($_POST['Register']))
    {    $schname= $_POST['schname'];
	$affid = $_POST['affid'];
	$phn = $_POST['phn'];
	$principal = $_POST['principal'];
	$teachers = $_POST['teachers'];
	$students = $_POST['students'];
	$girls = $_POST['girls'];
	$boys = $_POST['boys'];
	$gwashroom = $_POST['gwashroom'];
	$bwashroom = $_POST['bwashroom'];
	$fees = $_POST['fees'];
	$health = $_POST['health'];
	$sports = $_POST['sports'];
    }

// Server name must be localhost
$servername = "localhost";

// In my case, user name will be root
$username = "root";

// Password is empty
$password = "";

// Creating a connection
$conn = new mysqli($servername,
			$username, $password);

// Check connection
if ($conn->connect_error) {
	die("Connection failure: "
		. $conn->connect_error);
}

// Creating a database named geekdata
//$sql = "INSERT INTO `feedback` (`Name`, `Age`, `Marks`, `Mobile`) VALUES ('$name', '$age', '$marks', '$mobile');";  
//if ($conn->query($sql) == TRUE) {
$sql = "INSERT INTO techfest.`schools` (`schname`, `affid`, `phn`, `principal`,`teachers`,`students`,`girls`,`boys`,`gwashroom`,`bwashroom`,`fees`,`health`,`sports`) VALUES ('$schname', '$affid', '$phn', '$principal','$teachers','$students','$girls','$boys','$gwashroom','$bwashroom','$fees','$health','$sports');";

// Closing connection
$conn->close();
?>
